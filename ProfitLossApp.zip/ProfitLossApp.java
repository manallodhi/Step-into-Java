package ProfitLoss;

import java.util.Scanner;

public class ProfitLossApp {

	public static void main(String[] args) {
		
		 Scanner input = new Scanner(System.in);
	        Item[] items = new Item[4];
	        double totalProfit = 0;
	        double totalLoss = 0;

	        // Input for each item and object creation
	        for (int i = 0; i < 4; i++) {
	            System.out.print("Enter Cost Price of Item " + (i + 1) + ": ");
	            double cp = input.nextDouble();

	            System.out.print("Enter Selling Price of Item " + (i + 1) + ": ");
	            double sp = input.nextDouble();

	            items[i] = new Item(cp, sp);
	        }

	        // Display result for each item
	        System.out.println("\n--- Profit or Loss Report ---");
	        for (int i = 0; i < 4; i++) {
	            items[i].displayResult(i + 1);

	            double result = items[i].getProfitOrLoss();
	            if (result > 0)
	                totalProfit += result;
	            else
	                totalLoss += -result; // convert negative loss to positive
	        }

	        // Display overall result
	        System.out.println("\n--- Overall Summary ---");
	        if (totalProfit > totalLoss) {
	            System.out.println("Overall Profit = Rs. " + (totalProfit - totalLoss));
	        } else if (totalLoss > totalProfit) {
	            System.out.println("Overall Loss = Rs. " + (totalLoss - totalProfit));
	        } else {
	            System.out.println("No Overall Profit or Loss");
	        }

	        input.close();
	    }
	}
