package ProfitLoss;

public class Item {

	 double costPrice;
	    double sellingPrice;

	    // Constructor
	    Item(double costPrice, double sellingPrice) {
	        this.costPrice = costPrice;
	        this.sellingPrice = sellingPrice;
	    }

	    // Method to get profit or loss
	    double getProfitOrLoss() {
	        return sellingPrice - costPrice;
	    }

	    // Method to display result for this item
	    void displayResult(int itemNumber) {
	        double result = getProfitOrLoss();
	        if (result > 0) {
	            System.out.println("Item " + itemNumber + ": Profit of Rs. " + result);
	        } else if (result < 0) {
	            System.out.println("Item " + itemNumber + ": Loss of Rs. " + (-result));
	        } else {
	            System.out.println("Item " + itemNumber + ": No Profit, No Loss");
	        }
	    }


	
}
